import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-share-module',
  templateUrl: './share-module.page.html',
  styleUrls: ['./share-module.page.sass']
})
export class ShareModulePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
