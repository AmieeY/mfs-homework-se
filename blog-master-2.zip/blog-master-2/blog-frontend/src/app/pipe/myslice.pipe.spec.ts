import { MyslicePipe } from './myslice.pipe';

describe('MyslicePipe', () => {
  it('create an instance', () => {
    const pipe = new MyslicePipe();
    expect(pipe).toBeTruthy();
  });
});
